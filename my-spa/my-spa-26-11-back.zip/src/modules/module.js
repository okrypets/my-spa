'use strict';

const favoriteCout =() => {

}
