/*
import React, {PureComponent} from 'react';

//import PropTypes from 'prop-types';
import SingleItem from '../Components/SingleItem';
import shopData from '../shopItemArr';



class PageSingleItem extends PureComponent {

        render() {
                let shopItemId=parseInt(this.props.match.params.clid);

                let shopItemData=[...shopData.shopItemArr].find( c => c.id===shopItemId );
        return (
            <div className="Page_Catalog">
                <SingleItem item = {shopItemData} />
            </div>
        );

}

}

export default PageSingleItem;

 */
