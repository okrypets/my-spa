import React from 'react';

export default function PageMain() {
    return (
              <div className="Page_Main">
                  <h1>Page_Main!</h1>
              </div>
    );
}
    