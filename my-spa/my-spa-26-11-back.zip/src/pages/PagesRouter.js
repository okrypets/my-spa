import React from 'react';
import {Switch, Route, useRouteMatch} from "react-router-dom";

//import ShopCatalog from "../Components/ShopCatalog";
//import shopData from "../shopItemArr";
//import SingleItem from "../Components/SingleItem";

import PageMain from "./PageMain";
import PageCatalog from "./PageCatalog";
import PageBasket from "./PageBasket";
//import SingleItem from "../Components/SingleItem";
//import shopData from "../shopItemArr";
//import shopData from "../shopItemArr";

export default function PagesRouter() {
/*
    return (
        <Switch>
            <Route exact path="/">
                <PageMain />
            </Route>
            <Route path="/catalog" >
                <PageCatalog />
            </Route>
            <Route path="/basket">
                <PageBasket />
            </Route>

        </Switch>
    );

 */
}

    /*
     <Route path={`${match.path}/item-:itemId`} >
                <SingleItem {...this.props} item = {shopItem} />
            </Route>
    */
