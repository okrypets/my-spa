import {EventEmitter} from 'events';

let appEvents=new EventEmitter();
export {appEvents};
